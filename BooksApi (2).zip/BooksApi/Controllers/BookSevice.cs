﻿namespace BooksApi.Controllers
{
    public class BookSevice
    {
    }
}