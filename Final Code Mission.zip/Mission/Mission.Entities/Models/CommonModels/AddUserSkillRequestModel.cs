﻿namespace Mission.Entities.Models.CommonModels
{
    public class AddUserSkillRequestModel
    {
        public string Skill { get; set; }

        public int UserId { get; set; }
    }
}
