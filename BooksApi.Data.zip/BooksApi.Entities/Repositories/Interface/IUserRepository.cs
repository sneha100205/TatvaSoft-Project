﻿using BooksApi.Entities.Entities;
using System.Threading.Tasks;

using BooksApi.Entities.Entities;

namespace BooksApi.Entities.Repositories.Interface
{
    public interface IUserRepository
    {
        Task AddUser(User user);

        User? Login(string username, string password);
    }
}