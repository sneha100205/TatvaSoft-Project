﻿namespace BooksApi.Entities
{
    public class Class1
    {

    }
}
