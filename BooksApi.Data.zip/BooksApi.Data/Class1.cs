﻿namespace BooksApi.Data
{
    public class Class1
    {

    }
}
