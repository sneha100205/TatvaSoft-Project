﻿namespace BooksApi.Dto
{
    public class LoginReqDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
